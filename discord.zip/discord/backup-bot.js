const fs = require('fs');
const moment = require('moment-timezone');
const { Client, GatewayIntentBits, Partials } = require('discord.js');
const client = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMembers,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.MessageContent,
        GatewayIntentBits.GuildMessageReactions,
        GatewayIntentBits.GuildPresences
    ],
    partials: [Partials.Message, Partials.Channel, Partials.Reaction, Partials.GuildMember]
const TOKEN = 'MTI1NDQwMDQzMjUyOTQ3MzU3Ng.GI3M4L.ZbOcRDhKuXqurngXIjXW-RBJDdOPSQVGPYXsN0'; // Replace with your bot's token
const PREFIX = 'murtesa'; // Command prefix
const TARGET_USER_IDS = ['1253731609027416174', '1154724909516333057', '1244350359963566163', '1236034818735738923', '1238776371900055566', '1234645556991885364', '']; // Replace with user IDs to auto-kick
const TARGET_USERNAMES = ['itsbrix.', 'newone', 'username3']; // Replace with usernames to auto-kick
const ALLOWED_USER_IDS = ['1144195126097367123', '1058737274646437979', '1189050457860079756', '1212012130207801346']; // Specific user IDs allowed to use admin commands
// Ensure the database directory exists
const DATABASE_DIR = 'database';
if (!fs.existsSync(DATABASE_DIR)) {
    fs.mkdirSync(DATABASE_DIR);
// File paths for text log databases
const KICK_LOG_FILE = `${DATABASE_DIR}/kicked-people.txt`;
const ROLE_CHANGES_FILE = `${DATABASE_DIR}/role-changes.txt`;
const GUILD_LOG_FILE = `${DATABASE_DIR}/guild-events.txt`;
const MUTE_LOG_FILE = `${DATABASE_DIR}/muted-people.txt`;
const BAN_LOG_FILE = `${DATABASE_DIR}/banned-people.txt`;
const UNBAN_LOG_FILE = `${DATABASE_DIR}/unbanned-people.txt`;
client.once('ready', () => {
    console.log(`Logged in as ${client.user.tag}`);
client.on('messageCreate', async message => {
    if (!message.content.startsWith(PREFIX) || message.author.bot) return;
    const args = message.content.slice(PREFIX.length).trim().split(/ +/);
    const command = args.shift().toLowerCase();
    // Define the list of commands and their descriptions
    const commands = {
        hi: "Sends a welcome message.",
        security: "Checks the bot's security status.",
        help: "Displays this help message.",
        clear: "Clears a specified number of messages. Usage: `murtesa clear <number>`.",
        mute: "Mutes a mentioned user. Usage: `murtesa mute @user`.",
        unmute: "Unmutes a mentioned user. Usage: `murtesa unmute @user`.",
        admin: "Grants admin role to a mentioned user. Usage: `murtesa admin @user`.",
        unadmin: "Revokes admin role from a mentioned user. Usage: `murtesa unadmin @user`.",
        ban: "Bans a mentioned user. Usage: `murtesa ban @user`.",
        unban: "Unbans a user by their ID. Usage: `murtesa unban <userID>`."
    };
    // Check if the command is help, which can be used by anyone
    if (command === 'help') {
        let helpMessage = "Here are the available commands:\n";
        for (const [cmd, desc] of Object.entries(commands)) {
            helpMessage += `\`${PREFIX} ${cmd}\`: ${desc}\n`;
        }
        return message.channel.send(helpMessage);
    }
    // Check if the command is greet or security, which can be used by anyone
    if (command === 'hi') {
        return message.channel.send(`Hello, ${message.author.username} if you need help say command murtesa help`);
    } else if (command === 'security') {
        return message.channel.send(' :lock: I am online and I am doing my job :lock: ');
    }
    // Check if user is allowed to use admin commands
    if (!ALLOWED_USER_IDS.includes(message.author.id)) {
        return message.channel.send(`Only <@${ALLOWED_USER_IDS.join('>, <@')}> can use admin commands.`);
    }
    if (command === 'clear') {
        const amount = parseInt(args[0]);
        if (isNaN(amount) || amount <= 0) {
            return message.channel.send('Invalid command format. Use `' + PREFIX + 'clear <number>`.');
        }
        try {
            const fetched = await message.channel.messages.fetch({ limit: amount + 1 });
            message.channel.bulkDelete(fetched);
            message.channel.send(`Deleted ${amount} messages.`)
                .then(msg => {
                    setTimeout(() => msg.delete(), 5000); // Delete the response message after 5 seconds
                });
        } catch (error) {
            console.error('Error clearing messages:', error);
            message.channel.send('Error clearing messages. Check bot permissions.');
        }
    } else if (command === 'mute') {
        const member = message.mentions.members.first();
        if (!member) {
            return message.channel.send('Please mention a user to mute.');
        }
        const muteRole = message.guild.roles.cache.find(role => role.name === 'Muted'); // Replace 'Muted' with the name of your mute role
        if (!muteRole) {
            return message.channel.send('Mute role not found. Please create a role named "Muted".');
        }
        try {
            await member.roles.add(muteRole);
            message.channel.send(`Muted ${member.user.tag}.`);
            logMuteEvent(member.user.tag, message.author.tag);
        } catch (error) {
            console.error('Error muting user:', error);
            message.channel.send('Error muting user. Check bot permissions.');
        }
    } else if (command === 'unmute') {
        const member = message.mentions.members.first();
        if (!member) {
            return message.channel.send('Please mention a user to unmute.');
        }
        const muteRole = message.guild.roles.cache.find(role => role.name === 'Muted'); // Replace 'Muted' with the name of your mute role
        if (!muteRole) {
            return message.channel.send('Mute role not found. Please create a role named "Muted".');
        }
        try {
            await member.roles.remove(muteRole);
            message.channel.send(`Unmuted ${member.user.tag}.`);
            logUnmuteEvent(member.user.tag, message.author.tag);
        } catch (error) {
            console.error('Error unmuting user:', error);
            message.channel.send('Error unmuting user. Check bot permissions.');
        }
    } else if (command === 'admin') {
        const member = message.mentions.members.first();
        if (!member) {
            return message.channel.send('Please mention a user to grant admin.');
        }
        const adminRole = message.guild.roles.cache.find(role => role.name === 'Admin'); // Replace 'Admin' with the name of your admin role
        if (!adminRole) {
            return message.channel.send('Admin role not found. Please create a role named "Admin".');
        }
        try {
            await member.roles.add(adminRole);
            message.channel.send(`Granted admin to ${member.user.tag}.`);
            logAdminEvent(member.user.tag, message.author.tag, 'granted');
        } catch (error) {
            console.error('Error granting admin:', error);
            message.channel.send('Error granting admin. Check bot permissions.');
        }
    } else if (command === 'unadmin') {
        const member = message.mentions.members.first();
        if (!member) {
            return message.channel.send('Please mention a user to revoke admin.');
        }
        const adminRole = message.guild.roles.cache.find(role => role.name === 'Admin'); // Replace 'Admin' with the name of your admin role
        if (!adminRole) {
            return message.channel.send('Admin role not found. Please create a role named "Admin".');
        }
        try {
            await member.roles.remove(adminRole);
            message.channel.send(`Revoked admin from ${member.user.tag}.`);
            logAdminEvent(member.user.tag, message.author.tag, 'revoked');
        } catch (error) {
            console.error('Error revoking admin:', error);
            message.channel.send('Error revoking admin. Check bot permissions.');
        }
    } else if (command === 'ban') {
        const member = message.mentions.members.first();
        if (!member) {
            return message.channel.send('Please mention a user to ban.');
        }
        if (!member.bannable) {
            return message.channel.send('I cannot ban this user. Ensure that my role is higher than the user you want to ban.');
        }
        const reason = args.slice(1).join(' ') || 'No reason provided';
        try {
            await member.ban({ reason });
            message.channel.send(`Banned ${member.user.tag} for: ${reason}`);
            logBanEvent(member.user.tag, message.author.tag, reason);
        } catch (error) {
            console.error('Error banning user:', error);
            message.channel.send('Error banning user. Check bot permissions.');
        }
    } else if (command === 'unban') {
        const userId = args[0];
        if (!userId) {
            return message.channel.send('Please provide the ID of the user to unban.');
        }
        try {
            await message.guild.members.unban(userId);
            message.channel.send(`Unbanned user with ID: ${userId}`);
            logUnbanEvent(userId, message.author.tag);
        } catch (error) {
            console.error('Error unbanning user:', error);
            message.channel.send('Error unbanning user. Ensure the ID is correct and I have the right permissions.');
        }
    }
client.on('guildMemberAdd', async member => {
    if (TARGET_USER_IDS.includes(member.user.id) || TARGET_USERNAMES.includes(member.user.username)) {
        try {
            await member.kick('Blacklisted user.');
            console.log(`Kicked blacklisted user: ${member.user.tag}`);
            logKickEvent(member.user.tag, member.user.id);
        } catch (error) {
            console.error('Error kicking blacklisted user:', error);
        }
    }
client.on('guildMemberUpdate', (oldMember, newMember) => {
    const addedRoles = newMember.roles.cache.filter(role => !oldMember.roles.cache.has(role.id));
    const removedRoles = oldMember.roles.cache.filter(role => !newMember.roles.cache.has(role.id));
    const timestamp = getSomaliaTime();
    addedRoles.forEach(role => {
        console.log(`Role ${role.name} added to ${newMember.user.tag} at ${timestamp}`);
    });
    removedRoles.forEach(role => {
        console.log(`Role ${role.name} removed from ${newMember.user.tag} at ${timestamp}`);
    });
    logRoleChanges(newMember.user.tag, addedRoles, removedRoles, timestamp);
client.on('guildMemberRemove', member => {
    console.log(`Member ${member.user.tag} has left or was kicked from the server.`);
client.on('guildCreate', guild => {
    const data = `Bot added to guild: ${guild.name} (ID: ${guild.id}) at ${getSomaliaTime()}\n`;
    fs.appendFile(GUILD_LOG_FILE, data, (err) => {
        if (err) throw err;
        console.log(`Logged guild add event to ${GUILD_LOG_FILE}`);
    });
client.on('guildDelete', guild => {
    const data = `Bot removed from guild: ${guild.name} (ID: ${guild.id}) at ${getSomaliaTime()}\n`;
    fs.appendFile(GUILD_LOG_FILE, data, (err) => {
        if (err) throw err;
        console.log(`Logged guild remove event to ${GUILD_LOG_FILE}`);
    });
function logKickEvent(username, userId) {
    const data = `User: ${username} (${userId}) was kicked at ${getSomaliaTime()}\n`;
    fs.appendFile(KICK_LOG_FILE, data, (err) => {
        if (err) throw err;
        console.log(`Logged kick event to ${KICK_LOG_FILE}`);
    });
function logMuteEvent(mutedUsername, mutingUsername) {
    const data = `User: ${mutedUsername} was muted by ${mutingUsername} at ${getSomaliaTime()}\n`;
    fs.appendFile(MUTE_LOG_FILE, data, (err) => {
        if (err) throw err;
        console.log(`Logged mute event to ${MUTE_LOG_FILE}`);
    });
function logUnmuteEvent(unmutedUsername, unmutingUsername) {
    const data = `User: ${unmutedUsername} was unmuted by ${unmutingUsername} at ${getSomaliaTime()}\n`;
    fs.appendFile(MUTE_LOG_FILE, data, (err) => {
        if (err) throw err;
        console.log(`Logged unmute event to ${MUTE_LOG_FILE}`);
    });
function logAdminEvent(username, actioningUsername, action) {
    const data = `User: ${username} had admin ${action} by ${actioningUsername} at ${getSomaliaTime()}\n`;
    fs.appendFile(ROLE_CHANGES_FILE, data, (err) => {
        if (err) throw err;
        console.log(`Logged admin ${action} event to ${ROLE_CHANGES_FILE}`);
    });
function logRoleChanges(username, addedRoles, removedRoles, timestamp) {
    let logData = `Role changes for ${username} at ${timestamp}:\n`;
    addedRoles.forEach(role => {
        logData += `Role added: ${role.name}\n`;
    });
    removedRoles.forEach(role => {
        logData += `Role removed: ${role.name}\n`;
    });
    fs.appendFile(ROLE_CHANGES_FILE, logData, (err) => {
        if (err) throw err;
        console.log(`Logged role changes to ${ROLE_CHANGES_FILE}`);
    });
function logBanEvent(bannedUsername, banningUsername, reason) {
    const data = `User: ${bannedUsername} was banned by ${banningUsername} at ${getSomaliaTime()} for reason: ${reason}\n`;
    fs.appendFile(BAN_LOG_FILE, data, (err) => {
        if (err) throw err;
        console.log(`Logged ban event to ${BAN_LOG_FILE}`);
    });
function logUnbanEvent(unbannedUserId, unbanningUsername) {
    const data = `User ID: ${unbannedUserId} was unbanned by ${unbanningUsername} at ${getSomaliaTime()}\n`;
    fs.appendFile(UNBAN_LOG_FILE, data, (err) => {
        if (err) throw err;
        console.log(`Logged unban event to ${UNBAN_LOG_FILE}`);
    });
function getSomaliaTime() {
    return moment().tz("Africa/Mogadishu").format("YYYY-MM-DD HH:mm:ss");
client.login(TOKEN);
